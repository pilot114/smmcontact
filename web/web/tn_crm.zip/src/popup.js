function saveChanges() {

	chrome.storage.local.get('token', function(d) {
		if (d.token) {
			console.log("token loaded: " + d.token);
			input.value = d.token;
		}
	});

	var input = document.getElementById('input');
	$('#input').on('input', function(){
		var token = this.value;
		chrome.storage.local.set({'token': token}, function() {
			console.log("token saved");
		});
		$('#status').html('Token update!');
		// TODO: clear cache if token changed
	});
}

$(function() {
	saveChanges();

	$('#update').click(function(){
		$('#update_result').empty();

		chrome.storage.local.get('token', function(d) {
		    if (d.token) {
    			var user = {
		            'token': d.token
		        };
				preload(user);
				$('#update_result').append('<img id="preloader" src="/images/loader.gif">');

				var check = function() {
					console.log("popup check");
            		var flags = states.priceF && states.clientsF && states.phrasesF && states.tagsF;
				    if (flags) {
				        window.clearInterval(intervalID);
        				// SEND UPDATED STATES TO MAIN WINDOW
						console.log("send states from popup");
						chrome.runtime.sendMessage({states: states}, function(r) {
							$('#update_result').empty().append('<div>Сделано!</div>');
		            	});
				    }
				}
				var intervalID = window.setInterval(check, 200);
		    }
		});
	});
});
