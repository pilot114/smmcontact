createClient = function(e) {

    console.log('create!');
    user = e.data.user;

    // from vk
    getClientInfo(sel, function(r){

        client = clientNormalize(r.result, true);
        if (client) {
            client.vk_id = sel;

            clientRender(client, user);

            // api call for save client data
            chrome.runtime.sendMessage({api:"create_client", user:user, client:client}, function(r) {
                console.log(r);
            });
        }
    })
}
createOrder = function(e) {
    user = e.data.user;

    $('#order_item').remove();
    emptyOrder = {};
    emptyOrder.vk_id = sel;
    // api call for create default order data
    chrome.runtime.sendMessage({api:"create_order", user:user, order:emptyOrder}, function(r) {
        // caching order for update
        states.order = r.result;
        if (typeof r.result === 'object') {
            order = orderNormalize(r.result);
            orderRender(order, user);
        } else {
            console.log(r.result);
        }
    });
}


renderInit = function(url, user){
    // crunch for remove wh listener
    if (typeof intervalID_2 != "undefined") {
        window.clearInterval(intervalID_2);
        console.log("remove wh listener");
    }

    // fixes vk css
    $('.placeholder').empty();
    $('.ui_rmenu_slider').hide();
    $('.im-right-menu.ui_rmenu').css('width', '310px').css('max-width', '310px');

    sel = getQueryVariable(url, 'sel');

    $('.crm_panel').remove();
    console.log('crm_left_panel remove: ' + $('.crm_left_panel').length);
    $('.crm_left_panel').remove();

    // PRELOAD
    if (typeof states.clients == "undefined") {
        console.log("load data from server");
        preload(states.user, sel);
    } else {
        console.log("load data from cache");
    }

    if (sel) {
        console.log("CLIENT PAGE");

        getClientInfo(sel, function(r){
            console.log("vk_user info loaded from vk.api");
            states.vk_client = r.result;

                    $('.ui_rmenu[role=list]')
            .prepend("<div class='_im_ui_peers_list crm_panel'><div id='client'></div><div id='order'></div></div>");
            $('#page_layout')
            .prepend('<div class="crm_left_panel"><div id="reminders"></div><div id="phrases"></div></div>');


            // after preload
            var check = function() {
                console.log('try check');

                // states preload from cache or from server
                var preloadFlags = states.clients ||
                    states.priceF && states.clientsF && states.ordersF && states.phrasesF && states.tagsF;

                if (preloadFlags) {
                    console.log('flags checked, all data available');
                    window.clearInterval(intervalID);

                    if (!states.clients) {
                        cacher.saveState();
                    }

                    states.clientTags = [];
                    states.orderProducts = [];

                    findClient = null;
                    if (states.clients) {
                        for (var i = 0; i < states.clients.length; i++) {
                            if (states.clients[i].vk_id == sel) {
                                findClient = states.clients[i];
                            }
                        }
                    }

                    if (findClient) {
                        console.log("vk_client finded in states");
                        findClient = clientNormalize(findClient, false);
                        clientRender(findClient, user);
                    } else {
                        console.log("vk_client not in states. new client!");
                        // new client
                        norm_client = clientNormalize(states.vk_client, true);

                        if (norm_client) {
                            norm_client.vk_id = sel;
                            clientRender(norm_client, user);

                            // api call for save client data
                            chrome.runtime.sendMessage({api:"create_client", user:user, client:norm_client}, function(r) {
                                // save new client to cache and states
                                if (r.result) {
                                    states.clients.push(norm_client);
                                    cacher.saveState();
                                } else {
                                    alert("create_client error");
                                }
                            });
                        } else {
                            alert("Dont normalize vk_client/ main.js:163");
                        }
                    }
                    if (states.clients) {
                        remindersRender(states.clients);
                    }

                    var order = null;
                    if (states.order) {
                        order = orderNormalize(states.order);
                    }
                    orderRender(order, user);
                    $('#new_order').click( {"user":user}, createOrder );

                    if (states.phrases) {
                        phrasesClone = clone(states.phrases);
                        phrasesRender( groupBy(phrasesClone, 'type') );
                    }
                }
            }
            var intervalID = window.setInterval(check, 200);
        });

    }
    // dialogs
    var res = url.match(/^https:\/\/vk.com\/im.*/);
    if( res != null && !sel) {
        console.log("DIALOGS PAGE");

        if (states.clients) {
            console.log("dialogs render");

            $('#page_layout').prepend('<div class="crm_left_panel"><div id="debug"></div><div id="reminders"></div></div>');
            remindersRender(states.clients);
            dialogsRender(states.clients);
            debugRender();
        } else {
            console.log("пустой кэш");
            $('#page_layout').prepend('<div class="crm_left_panel"><div id="debug"></div><div id="reminders"></div></div>');
            remindersRender(states.clients);
            dialogsRender(states.clients);
            debugRender();
        }

        // check height window
        var check_2 = function() {
            var wh = $("html").height();
            // console.log( wh );

            if (states.window_height < wh) {
                states.window_height = wh;
                dialogsRender(states.clients);
                console.log( 'dialogsReview' );
            }
        }
        intervalID_2 = window.setInterval(check_2, 1000);
    }
}

$('.im_editable').on('keydown', function(e) {
    var editElem = $(e.target);
    var text = editElem.text();

    // backspace
    if (e.which == 8) {
        text = text.substring(0, text.length - 1);
    }
    // letters, numbers, russian keys
    if ( (e.which <= 90 && e.which >= 48)
        || e.which == 186
        || e.which == 188
        || e.which == 190
        || e.which == 219
        || e.which == 221
        || e.which == 222
    ) {
        text += e.key;
    }
    var searched = searchPhrases(text);

    renderAutocompleteIM(editElem, searched);

    var selectCb = function(sa) {
        $('.im_editable').removeAttr('contenteditable');
        $('.im_editable').text(sa);
        setTimeout(function() {
            $('.im_editable').attr('contenteditable', 'true');
        }, 10);
    }
    // up, down and enter key handling
    selectAutocomplete(e, selectCb);
});

function init(user) {
    console.log('init');

    url = window.location.href;

    renderInit(url, user);

    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        // when switch user in dialogs
        if (request.url) {
            cacher.loadToken();
            cacher.loadState();
            renderInit(request.url, user);
        }
    });

    // get update state from server
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        if (request.states) {
            console.log("update from popup");
            states = request.states;
            cacher.saveState();
            // todo: safe reload page?
        }
    });
}

cacher.loadToken();
cacher.loadState();

// check cache before init
var check_1 = function() {
    if (states.user && states.cache_loaded) {
        window.clearInterval(intervalID_1);
        init(states.user);
    }
}
var intervalID_1 = window.setInterval(check_1, 10);
