var settings = {
	"domain" : "http://89.223.27.167"
};
