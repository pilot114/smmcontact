var settings = {
	"domain" : "http://85.143.214.78"
}